/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author alexisdelahoz
 */
public class ListaPersonas implements Serializable {
    private ArrayList<Persona> listadoPersonas = new ArrayList<>(); 
    
    public void adicionarPersona(Persona elemento) {
        listadoPersonas.add(elemento);
    }
    
    public boolean buscarPersona(Persona elemento) {
        return listadoPersonas.contains(elemento);
    }
    
    public Persona buscarPersonaIndice(int indice) {
        return listadoPersonas.get(indice);
    }
    
    public boolean eliminarPersona(Persona elemento) {
        return listadoPersonas.remove(elemento);
    }
    
    public Persona eliminarPersonaIndice(int indice) {
        return listadoPersonas.remove(indice);
    }
    
       public DefaultTableModel getListPersonas() {
        DefaultTableModel modelo = new DefaultTableModel();
        String[] titulosColumnas = {"Cedula", "Nombre", "Apellido"};
        modelo.setColumnIdentifiers(titulosColumnas);
        for (int i = 0; i < listadoPersonas.size(); i++) {
            Persona actual = listadoPersonas.get(i);
            String[] contenidoPalabra = {actual.getCedula(), 
                                         actual.getNombre(), 
                                         ""+actual.getApellido()};
            modelo.addRow(contenidoPalabra);
        }
        
        return modelo; 
    }
       
    public int numeroPersonas() {
        return listadoPersonas.size();
    }

 /*
    METODOS PARA SERIALIZACION DE PERSONA
    */
    /**
     * Metodo para serializar
     */
    public void escribirPersona(String nombreArchivo) throws FileNotFoundException, IOException {
        //Abrir Archivo de Salida
        File archivo = new File(nombreArchivo);
        //Abrir Flujo de Archivo de Salida
        FileOutputStream flujoASalida = new FileOutputStream(archivo);
        //Abrir Flujo de Objetos de Salida
        ObjectOutputStream flujoOSalida = new ObjectOutputStream(flujoASalida);
        //Escribir la instancia actual
        flujoOSalida.writeObject(this);
        //Cerrar Flujos
        flujoOSalida.close();
        flujoASalida.close();
    } 
      /**
     * Metodo para deserializar
     */
    public static ListaPersonas leerPersona(String nombreArchivo) throws FileNotFoundException, IOException, ClassNotFoundException {
        //Abrir Archivo de Entrada
        File archivo = new File(nombreArchivo);
        //Abrir Flujo de Archivo de Entrada
        FileInputStream flujoAEntrada = new FileInputStream(archivo);
        //Abrir Flujo de Objeto de Entrada
        ObjectInputStream flujoOEntrada = new ObjectInputStream(flujoAEntrada);
        //Leer la instancia
        ListaPersonas Lectura = (ListaPersonas) flujoOEntrada.readObject();
        //Cerrar Flujos
        flujoOEntrada.close();
        flujoAEntrada.close();
        //Retorno
        return Lectura;
    }
}
