package edu.cuc.flores;

import java.util.Objects;

/**
 *
 * @author alexisdelahoz
 */
public class Especie {
    private String nombre;
    private int periodoFlorescencia; //Dias
    private String temporadaSiembra; 
    private String sueloApropiado;
    private String exposicionSol; //Alta, Media, Baja

    public Especie(String nombre, int periodoFlorescencia, String temporadaSiembra, 
            String sueloApropiado, String exposicionSol) {
        this.nombre = nombre;
        this.periodoFlorescencia = periodoFlorescencia;
        this.temporadaSiembra = temporadaSiembra;
        this.sueloApropiado = sueloApropiado;
        this.exposicionSol = exposicionSol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getPeriodoFlorescencia() {
        return periodoFlorescencia;
    }

    public void setPeriodoFlorescencia(int periodoFlorescencia) {
        this.periodoFlorescencia = periodoFlorescencia;
    }

    public String getTemporadaSiembra() {
        return temporadaSiembra;
    }

    public void setTemporadaSiembra(String temporadaSiembra) {
        this.temporadaSiembra = temporadaSiembra;
    }

    public String getSueloApropiado() {
        return sueloApropiado;
    }

    public void setSueloApropiado(String sueloApropiado) {
        this.sueloApropiado = sueloApropiado;
    }

    public String getExposicionSol() {
        return exposicionSol;
    }

    public void setExposicionSol(String exposicionSol) {
        this.exposicionSol = exposicionSol;
    }

    @Override
    public String toString() {
        return "Especie{" + "nombre=" + nombre + ", periodoFlorescencia=" + periodoFlorescencia + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.nombre);
        hash = 59 * hash + this.periodoFlorescencia;
        hash = 59 * hash + Objects.hashCode(this.temporadaSiembra);
        hash = 59 * hash + Objects.hashCode(this.sueloApropiado);
        hash = 59 * hash + Objects.hashCode(this.exposicionSol);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Especie other = (Especie) obj;
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        return true;
    }
    
    

    public static void main(String[] args) {
        Especie esp1 = new Especie("Margaritus", 12, "Enero", "Seco", "Media");
        Especie esp2 = new Especie("Margaritus Colombianus", 12, "Enero", "Seco", "Media");
        System.out.println(""+(esp1.equals(esp2)));
    }
  
    
    
    
}
