/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.externas;

import edu.cuc.pruebas.Clase1;

/**
 *
 * @author alexisdelahoz
 */
public class Clase4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Clase1 objeto1 = new Clase1();
        objeto1.contador = 23;
        System.out.println(""+objeto1.contador);
    }
    
}
