package edu.cuc.modelo;

import java.util.Arrays;

/**
 *
 * @author alexisdelahoz
 */
public class PruebasMatrices {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Creacion de la matriz
        int[] vector1 = new int[10];
        //int[][] matriz1 = new int[5][3]; //NO Cuadrada
        int[][] matriz1 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}, {-1, 10, 8}, {2, 4, 20}};
        String[][] matriz2 = new String[2][2];
        System.out.println("Matriz 1: "+ Arrays.deepToString(matriz1) );
        System.out.println("\nMatriz 2: "+ Arrays.deepToString(matriz2) );
        
        for (int i = 0; i < matriz1.length; i++) { //Recorrido por Filas
            for (int j = 0; j < matriz1[i].length; j++) { //Recorido por Columnas
                //System.out.print("i: "+i+", j: "+j+" : "+matriz1[i][j]+"\t");
                System.out.print(matriz1[i][j]+"\t");
            }
            System.out.println("");
            
        }
        
        for (int i = 0; i < matriz1[i].length; i++) {
            for (int j = 0; j < matriz1.length; j++) {
                //System.out.print("j: "+j+", i: "+i+" : "+matriz1[j][i]+"\t");  
                System.out.print(matriz1[j][i]+"\t");  
            }
            System.out.println("");
        }
        
    }
    
}
