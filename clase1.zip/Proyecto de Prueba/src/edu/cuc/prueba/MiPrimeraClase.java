/*
  To change this license header, choose License Headers in Project Properties.
  To change this template file, choose Tools | Templates
  and open the template in the editor.
 */
package edu.cuc.prueba;

import edu.cuc.clases.Clase2;

/**
 *
 * @author alexisdelahoz
 */
public class MiPrimeraClase {
    private int contador; // Este es el contador
    public int contador2;
    protected int contador3;
    int contador4;
    
    public int sumar(int numero1, int numero2) {
        return numero1 + numero2;
    }
    
    public void mostrar() {
        
    }
    
    
}
