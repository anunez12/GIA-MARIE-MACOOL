/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.modelo;

/**
 *
 * @author alexisdelahoz
 */
public class Matrices {
    public static int[][] mayorMenorCadaColunna(int[][] matriz) {
        int[][] respuesta = new int[matriz[0].length][2];
        for (int i = 0; i < matriz[0].length; i++) {
            int mayor = matriz[0][i];
            int menor = matriz[0][i];
            for (int j = 0; j < matriz.length; j++) {
                if (matriz[j][i] > mayor) {
                    mayor = matriz[j][i];
                }
                if (matriz[j][i] < menor) {
                    menor = matriz[j][i];
                }
            }
            respuesta[i][0] = mayor;
            respuesta[i][1] = menor;
        }
        return respuesta;
    }
}
