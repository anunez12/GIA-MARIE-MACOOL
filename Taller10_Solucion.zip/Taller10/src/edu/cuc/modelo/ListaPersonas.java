package edu.cuc.modelo;

import java.util.ArrayList;

/**
 *
 * @author alexisdelahoz
 */
public class ListaPersonas {
    private ArrayList<Persona> listado = new ArrayList<>();

    public void adicionar(Persona nuevaPersona) {
        listado.add(nuevaPersona);
    }
    
    public boolean buscar(Persona persona) {
        return listado.contains(persona);
    }
    
    public boolean eliminar(Persona persona) {
        return listado.remove(persona);
    }
}
