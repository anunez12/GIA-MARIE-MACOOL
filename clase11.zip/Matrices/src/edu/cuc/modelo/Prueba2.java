package edu.cuc.modelo;

/**
 *
 * @author alexisdelahoz
 */
public class Prueba2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String[][] mat = {{"A", "B", "C"},
                          {"C", "E", "C"}};  
        System.out.println("R1: "+Matrices.buscarElemento(mat, "C"));
        System.out.println("R2: "+Matrices.buscarElementoPosicion(mat, "C"));
    }
    
}
