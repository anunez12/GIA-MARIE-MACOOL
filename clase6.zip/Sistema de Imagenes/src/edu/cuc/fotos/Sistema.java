package edu.cuc.fotos;

import java.util.ArrayList;

/**
 *
 * @author alexisdelahoz
 */
public class Sistema {
    private ArrayList<Foto> fotos = new ArrayList<>();
    private ArrayList<Etiqueta> etiquetas = new ArrayList<>();
    private ArrayList<Usuario> usuarios = new ArrayList<>();

    public Sistema() {
    }
    
    
}
