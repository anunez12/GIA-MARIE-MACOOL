package edu.cuc.modelo;

import java.util.ArrayList;

/**
 *
 * @author alexisdelahoz
 */
public class Matrices {
    /**
     * Busqueda de un elemento en una matriz
     * 
     * @param matriz La matriz en la que se buscará el elemento
     * @param dato   El elemento a buscar
     * @return true si el elemento es encontrado, false en caso contrario
     */
    public static boolean buscarElemento(String[][] matriz, String dato) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if (dato.equals(matriz[i][j])) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Busqueda de un elemento en una matriz
     * 
     */
    public static Posicion buscarElementoPosicion(String[][] matriz, String dato) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                if (dato.equals(matriz[i][j])) {
                    return new Posicion(i, j);
                }
            }
        }
        return null;
    }

    /**
     * Comparacion de Matrices
     */
    public static boolean comparar(String[][] matriz1, String[][] matriz2) {
        //Verificar dimension
        if (matriz1.length == matriz2.length &&
            matriz1[0].length == matriz2[0].length) {
            //Verificacion Contenido
            for (int i = 0; i < matriz1.length; i++) {
                for (int j = 0; j < matriz1[0].length; j++) {
                    if (!matriz1[i][j].equals(matriz2[i][j])) {
                        return false;
                    }
                }
            }
            return true;
        } else {
            return false;
        }
    }
    
    
    public static class Posicion {
        private int fila;
        private int columna;

        public Posicion(int fila, int columna) {
            this.fila = fila;
            this.columna = columna;
        }

        public int getFila() {
            return fila;
        }

        public void setFila(int fila) {
            this.fila = fila;
        }

        public int getColumna() {
            return columna;
        }

        public void setColumna(int columna) {
            this.columna = columna;
        }

        @Override
        public int hashCode() {
            int hash = 3;
            hash = 47 * hash + this.fila;
            hash = 47 * hash + this.columna;
            return hash;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final Posicion other = (Posicion) obj;
            if (this.fila != other.fila) {
                return false;
            }
            if (this.columna != other.columna) {
                return false;
            }
            return true;
        }

        @Override
        public String toString() {
            return "[" + fila + ", " + columna + "]";
        }
    }
    
    /**
     * Verificar si es cuadrada la matriz
     * @param matrix
     * @return
     */
    public static boolean esCuadrada(String[][] matrix) {
        return matrix.length == matrix[0].length;
    }

    /**
     * Determina la diagonal principal de la matriz
     * @param matrix
     * @return
     */
    public static ArrayList<String> diagonalPrincipal(String[][] matrix) {
        if (esCuadrada(matrix)) {
            ArrayList<String> diagonal = new ArrayList<>();
            for (int i = 0; i < matrix.length; i++) {
                diagonal.add(matrix[i][i]);
            }
            return diagonal;
        } else {
            return null;
        }
    }
    
    public static String[][] transpuesta(String[][] matriz) {
        //Matriz Resultado
        String[][] respuesta = new String[matriz[0].length][matriz.length];
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[0].length; j++) {
                respuesta[j][i] = matriz[i][j];
            }
        }
        return respuesta;
    }

}
