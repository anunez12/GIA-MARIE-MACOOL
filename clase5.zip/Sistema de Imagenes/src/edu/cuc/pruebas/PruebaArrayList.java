package edu.cuc.pruebas;

import edu.cuc.fotos.Usuario;
import java.util.ArrayList;

/**
 *
 * @author alexisdelahoz
 */
public class PruebaArrayList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Creacion
        ArrayList<String> listaCadenas = new ArrayList<>();
        ArrayList<Integer> listaEnteros = new ArrayList<>();
        ArrayList<Double> listaReales = new ArrayList<>();
        ArrayList<Usuario> listaUsuarios = new ArrayList<>();
        //Insercion
        listaCadenas.add("A");
        listaCadenas.add("B");
        listaCadenas.add("D");
        listaCadenas.add("E");
        System.out.println(""+listaCadenas);
        listaCadenas.add(1, "C");
        System.out.println(""+listaCadenas);
        listaCadenas.set(2, "Y");
        listaCadenas.add("D");
        System.out.println(""+listaCadenas);
        System.out.println("IndexOf D: "+listaCadenas.indexOf("Z"));
        System.out.println("LastIndexOf D: "+listaCadenas.lastIndexOf("D"));
        listaCadenas.remove("D");
        System.out.println(""+listaCadenas);
        System.out.println(""+listaCadenas.remove("Z"));
        System.out.println(""+listaCadenas);
        System.out.println("Contains D: "+listaCadenas.contains("D"));
        System.out.println("Cadenas: "+listaCadenas.size());
        System.out.println("Enteros: "+listaEnteros.size());
        
        System.out.println("Posicion: "+listaCadenas.get(0));
        for (int i = 0; i < listaCadenas.size(); i++) {
            String actual = listaCadenas.get(i);
            System.out.println("i:"+i+" - "+actual);
        }
    }
    
}
