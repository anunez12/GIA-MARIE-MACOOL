package edu.cuc.fotos;

/**
 *
 * @author alexisdelahoz
 */
public class Sistema {
    private Foto[] fotos;
    private Etiqueta[] etiquetas;
    private Usuario[] usuarios;

    public Sistema() {
    }
    
    
}
