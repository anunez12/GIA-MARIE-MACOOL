package edu.cuc.pruebas;

/**
 *
 * @author alexisdelahoz
 */
public class Vectores {
    /**
     * Promedio de los elementos de un vector de enteros
     */
    public static double promedioVector(int[] lista) {
        double suma = 0;
        for (int i = 0; i < lista.length; i++) {
            System.out.println("i: "+i+" : "+lista[i]);
            suma += lista[i];
        }
        return suma / lista.length;
    }
    
    /**
     * Numero de apariciones de un elemento en un vector de enteros
     * 
     */
    
    public static int numeroApariciones(int elemento, int[] lista) {
        int contador = 0;
        for (int i = 0; i < lista.length; i++) {
            if (elemento == lista[i]) {
                contador++;
            }
        }
        return contador;
    }
    
    /**
     * 
     * @param args 
     */
    
    public static void main(String[] args) {
        int[] vector1 = {10, 20, 30, 40,30};
        //System.out.println(""+promedioVector(vector1));
        System.out.println("Apariciones: "+numeroApariciones(25, vector1));
        System.out.println("Apariciones: "+numeroApariciones(30, vector1));
    }
}
