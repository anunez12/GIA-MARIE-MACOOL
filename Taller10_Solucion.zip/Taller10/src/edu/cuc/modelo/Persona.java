package edu.cuc.modelo;

/**
 *
 * @author alexisdelahoz
 */
public class Persona {
    private int id;
    private char sexo;
    private double sueldo;
    private boolean trabajo = true;

    public Persona(int id, char sexo, double sueldo) {
        this.id = id;
        this.sexo = sexo;
        this.sueldo = sueldo;
    }

    public int getId() {
        return id;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.id;
        hash = 79 * hash + this.sexo;
        hash = 79 * hash + (int) (Double.doubleToLongBits(this.sueldo) ^ (Double.doubleToLongBits(this.sueldo) >>> 32));
        hash = 79 * hash + (this.trabajo ? 1 : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Persona other = (Persona) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

    public void setId(int id) {
        this.id = id;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public boolean isTrabajo() {
        return trabajo;
    }

    public void setTrabajo(boolean trabajo) {
        this.trabajo = trabajo;
    }

    @Override
    public String toString() {
        return id + ", " + sexo + ", " + sueldo + ", trabajo=" + trabajo + '}';
    }
    
    
}
