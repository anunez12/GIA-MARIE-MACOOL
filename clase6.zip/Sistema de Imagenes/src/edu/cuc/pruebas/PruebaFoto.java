/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.pruebas;

import edu.cuc.fotos.Etiqueta;
import edu.cuc.fotos.Foto;
import edu.cuc.fotos.Usuario;

/**
 *
 * @author alexisdelahoz
 */
public class PruebaFoto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Foto nuevaFoto = new Foto("foto1.jpg", "Foto", "jpg", 10, 1000, "publico");
        Usuario nuevoUsuario = new Usuario("wenceslao", "12345", "wenceslao@cuc.edu.co");
        Etiqueta nuevaEtiqueta = new Etiqueta("Universidad de la Costa", nuevoUsuario);
        nuevaFoto.adicionarEtiqueta(nuevaEtiqueta);
        System.out.println("Foto: "+nuevaFoto);
    }
    
}
