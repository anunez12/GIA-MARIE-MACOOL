package edu.cuc.palabras;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author alexisdelahoz
 */
public class Diccionario implements Serializable {
    private ArrayList<Palabra> listadoPalabras = new ArrayList<>();
    
    public void adicionarPalabra(Palabra palabraNueva) {
        listadoPalabras.add(palabraNueva);
    }
    
    public boolean buscarPalabra(Palabra palabraNueva) {
        return listadoPalabras.contains(palabraNueva);
    }
    
    public Palabra buscarPalabra(String palabra) {
        for (int i = 0; i < listadoPalabras.size(); i++) {
            Palabra actual = listadoPalabras.get(i);
            if (actual.getPalabra().equals(palabra)) {
                return actual;
            }
        }
        return null;
    }
    
    public boolean eliminarPalabra(Palabra palabraNueva) {
        return listadoPalabras.remove(palabraNueva);
    }

    @Override
    public String toString() {
        return "Diccionario{" + "listadoPalabras=" + listadoPalabras + '}';
    }
    
     /**
     * Metodo para mostrar los sinonimos en un modelo de JTable
     */
    public DefaultTableModel getListSinonimos() {
        DefaultTableModel modelo = new DefaultTableModel();
        String[] titulosColumnas = {"Palabra", "Significado", "Cant. Sinonimos"};
        modelo.setColumnIdentifiers(titulosColumnas);
        for (int i = 0; i < listadoPalabras.size(); i++) {
            Palabra actual = listadoPalabras.get(i);
            String[] contenidoPalabra = {actual.getPalabra(), 
                                         actual.getSignificado(), 
                                         ""+actual.cantidadSinonimos()};
            modelo.addRow(contenidoPalabra);
        }
        
        return modelo;
    }
    
    /*
    METODOS PARA SERIALIZACION DE DICCIONARIO
    */
    /**
     * Metodo para serializar
     */
    public void escribirDiccionario(String nombreArchivo) throws FileNotFoundException, IOException {
        //Abrir Archivo de Salida
        File archivo = new File(nombreArchivo);
        //Abrir Flujo de Archivo de Salida
        FileOutputStream flujoASalida = new FileOutputStream(archivo);
        //Abrir Flujo de Objetos de Salida
        ObjectOutputStream flujoOSalida = new ObjectOutputStream(flujoASalida);
        //Escribir la instancia actual
        flujoOSalida.writeObject(this);
        //Cerrar Flujos
        flujoOSalida.close();
        flujoASalida.close();
    }
    
    /**
     * Metodo para deserializar
     */
    public static Diccionario leerDiccionario(String nombreArchivo) throws FileNotFoundException, IOException, ClassNotFoundException {
        //Abrir Archivo de Entrada
        File archivo = new File(nombreArchivo);
        //Abrir Flujo de Archivo de Entrada
        FileInputStream flujoAEntrada = new FileInputStream(archivo);
        //Abrir Flujo de Objeto de Entrada
        ObjectInputStream flujoOEntrada = new ObjectInputStream(flujoAEntrada);
        //Leer la instancia
        Diccionario diccionarioLeido = (Diccionario) flujoOEntrada.readObject();
        //Cerrar Flujos
        flujoOEntrada.close();
        flujoAEntrada.close();
        //Retorno
        return diccionarioLeido;
    }
}
