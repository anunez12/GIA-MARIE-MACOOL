package edu.cuc.estudiantes;

import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

/**
 *
 * @author alexisdelahoz
 */
public class Estudiante {
    private String nombreCompleto;
    private String id;
    private Date fechaNacimiento;
    private String carrera;
    private ArrayList<Double> notas = new ArrayList<>();

    public Estudiante(String nombreCompleto, String id) {
        this.nombreCompleto = nombreCompleto;
        this.id = id;
    }

    public Estudiante(String nombreCompleto, String id, Date fechaNacimiento, String carrera) {
        this.nombreCompleto = nombreCompleto;
        this.id = id;
        this.fechaNacimiento = fechaNacimiento;
        this.carrera = carrera;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 79 * hash + Objects.hashCode(this.nombreCompleto);
        hash = 79 * hash + Objects.hashCode(this.id);
        hash = 79 * hash + Objects.hashCode(this.fechaNacimiento);
        hash = 79 * hash + Objects.hashCode(this.carrera);
        hash = 79 * hash + Objects.hashCode(this.notas);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Estudiante other = (Estudiante) obj;
        if (!Objects.equals(this.id, other.id)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Estudiante{" + "nombreCompleto=" + nombreCompleto + ", id=" + id + ", notas=" + notas + '}';
    }
    
    //Gestion de Lista
    public void adicionarNota(double nota) {
        notas.add(nota);
    }
    
    public boolean buscarNota(double nota) {
        return notas.contains(nota);
    }
    
    public boolean eliminarNota(double nota) {
        return notas.remove(nota);
    }
    
    //Metodos de Notas
    
    /**
     * Mayor nota del estudiante
     */
    public double mayorNota() {
        double mayor = notas.get(0);
        for (int i = 0; i < notas.size(); i++) {
            Double actual = notas.get(i);
            if (actual > mayor) {
                mayor = actual;
            }
            
        }
        return mayor;
    }
    
    /**
     * Numero de veces que aparece una nota dada
     */
    public int numeroVecesApareceNota(double nota) {
        int contador = 0;
        for (int i = 0; i < notas.size(); i++) {
            Double actual = notas.get(i);
            if (nota == actual) {
                contador++;
            }
        }
        return contador;
    }
    
}
