/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.fotos;

/**
 *
 * @author alexisdelahoz
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Usuario usu = new Usuario("a", "b", "x");
        Usuario usu1 = new Usuario("a", "b", "y");
        System.out.println(""+usu.equals(usu1));
    }
    
}
