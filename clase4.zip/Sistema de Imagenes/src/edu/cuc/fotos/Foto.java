package edu.cuc.fotos;

import java.util.Arrays;
import java.util.Objects;

/**
 *
 * @author alexisdelahoz
 */
public class Foto {
   private String url;
   private String nombreArchivo;
   private String tipoDatos;
   private double tamano;
   private int resolucion;
   private String permiso;
   private Etiqueta[] etiquetas;

    public Foto(String url, String nombreArchivo, String tipoDatos, double tamano, int resolucion, String permiso) {
        this.url = url;
        this.nombreArchivo = nombreArchivo;
        this.tipoDatos = tipoDatos;
        this.tamano = tamano;
        this.resolucion = resolucion;
        this.permiso = permiso;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + Objects.hashCode(this.url);
        hash = 67 * hash + Objects.hashCode(this.nombreArchivo);
        hash = 67 * hash + Objects.hashCode(this.tipoDatos);
        hash = 67 * hash + (int) (Double.doubleToLongBits(this.tamano) ^ (Double.doubleToLongBits(this.tamano) >>> 32));
        hash = 67 * hash + this.resolucion;
        hash = 67 * hash + Objects.hashCode(this.permiso);
        hash = 67 * hash + Arrays.deepHashCode(this.etiquetas);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Foto other = (Foto) obj;
        if (!Objects.equals(this.url, other.url)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Foto{" + "url=" + url + ", nombreArchivo=" + nombreArchivo + ", tipoDatos=" + tipoDatos + ", tamano=" + tamano + ", resolucion=" + resolucion + ", permiso=" + permiso + ", etiquetas=" + etiquetas + '}';
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public String getTipoDatos() {
        return tipoDatos;
    }

    public void setTipoDatos(String tipoDatos) {
        this.tipoDatos = tipoDatos;
    }

    public double getTamano() {
        return tamano;
    }

    public void setTamano(double tamano) {
        this.tamano = tamano;
    }

    public int getResolucion() {
        return resolucion;
    }

    public void setResolucion(int resolucion) {
        this.resolucion = resolucion;
    }

    public String getPermiso() {
        return permiso;
    }

    public void setPermiso(String permiso) {
        this.permiso = permiso;
    }

    public Etiqueta[] getEtiquetas() {
        return etiquetas;
    }

    public void setEtiquetas(Etiqueta[] etiquetas) {
        this.etiquetas = etiquetas;
    }
   
   
}
