/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.pruebas;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author alexisdelahoz
 */
public class PruebaVectores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numero1 = 10;
        int numero2 = 20;
//        System.out.println("Suma: "+(numero1+numero2));
        //Arreglos
        int[] listaEnteros = new int[20];
        ArrayList<Integer> listaDinamica = new ArrayList<>();
        System.out.println("Arreglo: "+Arrays.toString(listaEnteros));
        System.out.println("ArrayList: "+listaDinamica);
        listaEnteros[0] = 2500;
        listaEnteros[19] = 300;
        listaDinamica.add(2500);
        listaDinamica.add(300);
        //listaDinamica.add(19, 300);
        System.out.println("Arreglo: "+Arrays.toString(listaEnteros));
        System.out.println("ArrayList: "+listaDinamica);
//        System.out.println("Suma: "+(listaEnteros[0] + listaEnteros[19]));
        int suma = 0;
        for (int i = 0; i < listaEnteros.length; i++) {
            System.out.println("i: "+i + " listaEnteros[i]: "+listaEnteros[i]);
            suma += listaEnteros[i];
        }
        System.out.println("Suma Vector: "+suma);
        
        int[] listaEnteros2 = {1, -2, 30, 14, 55, 61, -7, 8, 9 , 100};
        System.out.println("Arreglo2: "+Arrays.toString(listaEnteros2));
    }
    
}
