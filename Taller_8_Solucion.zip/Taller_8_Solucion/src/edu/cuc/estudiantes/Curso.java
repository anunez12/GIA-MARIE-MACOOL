package edu.cuc.estudiantes;

import java.util.ArrayList;

/**
 *
 * @author alexisdelahoz
 */
public class Curso {
    private String nombre;
    private ArrayList<Estudiante> listado = new ArrayList<>();
    
    public void adicionar(Estudiante nuevoEstudiante) {
        listado.add(nuevoEstudiante);
    }
    
    public boolean buscar(Estudiante estudiante) {
        return listado.contains(estudiante);
    }
    
    public boolean eliminar(Estudiante estudiante) {
        return listado.remove(estudiante);
    }

    @Override
    public String toString() {
        return "Curso{" + "nombre=" + nombre + ", listado=" + listado + '}';
    }
    
    
    
}
